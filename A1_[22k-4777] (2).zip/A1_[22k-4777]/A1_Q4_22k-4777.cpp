#include <iostream>
#include <string>
#include<cstdlib>
#include<ctime>
using namespace std;

class Movie {
private:
    string movies[9] = {"Avengers End Game", "Infinity War", "Civil War", "Khan", "Jawani Phir Nhi Aani", "Life At Fast", "Dday", "CivilWar", "Harley Queen"};
    int array[9] = {2, 12, 3, 2, 4, 5, 7, 7, 9};
public:
    void show() {
        for (int i = 0; i < 9; i++) {
            cout << "Movie Name: " << movies[i] << " is shown at time: " << array[i] << ":00 PM" << endl;
        }
    }
    string get_movies(int name) {
       if(name<10)
       {
       //	cout<<array[name];
       	return movies[name];
	   }
	   
        
        return "UnExpectedError"; // return -1 if the movie name is not found
}
int gettime(int name)
	   {
	   	return array[name];
	   }
};

class Ticket {
private:
    int row_num;
    int seat_num;
    int ticket_id;
    bool sold;
    string movie;
    int time;
public:
Ticket()
{
	
}

    Ticket(int r, int s,int id,string m,int t) {
        row_num = r;
        seat_num = s;
        ticket_id=id;
        sold = false;
        this->movie=m;
        this->time=t;
    }

    static const int MAX_TICKETS = 100;
    static Ticket tickets[MAX_TICKETS];
    static int num_tickets;
void append_record(int r, int s, int id,string movie,int time) {
    for (int i = 0; i < num_tickets; i++) {
        if (tickets[i].ticket_id==id && tickets[i].sold ==true) {
            cout << "Sorry, seat is already booked by ticket with ID " << tickets[i].ticket_id << endl;
            return;
        }
    }

    if (num_tickets < MAX_TICKETS) {
        tickets[num_tickets] = Ticket(r, s, id,movie,time);
        tickets[num_tickets].sold=true;
        
        num_tickets++;
        
        cout << "Ticket booked successfully" << endl;
       this->check(id); // Add the function call to check the ticket record
    } else {
        cout << "Sorry, no more tickets available" << endl;
    }
}


void check(int id)
{
	 for (int i = 0; i < num_tickets; i++) {
        if (tickets[i].ticket_id==id && tickets[i].sold ==true) {
        	cout<<"*****************************************"<<endl;
            cout<<"ID == "<<tickets[i].ticket_id<<endl;
            cout<<"Booked Seat No :"<<tickets[i].seat_num<<endl;
            cout<<"Booked Row No :"<<tickets[i].row_num<<endl;
            cout<<"Booked Movie "<<tickets[i].movie<<" at This Time :"<<tickets[i].time<<endl;
            cout<<"************************************************"<<endl;
        }
}
}

};

Ticket Ticket::tickets[Ticket::MAX_TICKETS];
int Ticket::num_tickets = 0;

int main() {
	cout<<"Muhammad Haris 22k-4777"<<endl;
	cout<<"************************************************"<<endl;
	
Ticket t1;
    Movie my_movie;
    string name;
    string movie;
    int time;
    int r,s;
    int id;
    int num;
    char ch;
    
    while(1){
	
    cout<<"Enter Your Name: Means Your Role No in the format 22k-4777"<<endl;
    cin>>name;
    id = std::stoi(name.substr(4, 2));
    cout<<"These Movies Are Available"<<endl;
    my_movie.show();
    cout<<"Which Movies You Wanna to see "<<endl;
    cout<<"Enter Number"<<endl;
    cin>>num;
    if(my_movie.get_movies(num) == "UnExpectedError")
    {
        cout<<"Not Available Or Entered Wrong"<<endl;
            return 0;
    }
    else
    {
        cout<<"This Movie: "<<my_movie.get_movies(num)<<" Is Shown On Time: "<<my_movie.gettime(num)<<":00 PM"<<endl;
        movie=my_movie.get_movies(num);
        time=my_movie.gettime(num);
    }
   s=(rand()%100-10+1)+10;
    //cout<<"Enter Row Number"<<endl;
    r=(rand()%50-10+1)+1;

  Ticket ticket;
ticket.append_record(r, s, id, movie, time);


    cout<<"Do You Wanna to Buy more tickets"<<endl;
    cout<<"If Yes Enter Y/y else no enter N/n"<<endl;
    cin>>ch;
    if((ch=='n')||(ch=='N')){
    break;
}
}
char chic;
cout<<"Do You Want To see Ticket Info"<<endl;
cout<<"If Yes Enter Y else no"<<endl;
cin>>chic;
switch(chic)
{
	case 'Y':
		case 'y':
			cout<<"Enter ID"<<endl;
			cin>>id;
			t1.check(id);
			break;
}
return 0;
}
