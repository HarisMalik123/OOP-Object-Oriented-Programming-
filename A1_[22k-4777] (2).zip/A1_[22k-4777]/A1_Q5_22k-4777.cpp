#include<iostream>
#include<string>
using namespace std;
class User;
class User{
    private:
    int  id;
    string name;
    int age;
    float height;
    string gender;
    float shoe_size;
    public:
    	User(){
    		
		}
    User(int id,string n,float f,string g,float s,int a)
    {
this->id=id;
name=n;
age=a;
height=f;
gender=g;
shoe_size=s;
    }
    void set_name(string name)
    {
        this->name=name;
    }
    void set_age(int a)
    {
        age=a;
    }
    void set_height(float h)
    {
        height=h;
    }
    void set_gender(string Gender)
    {
        gender=Gender;
    }
    void set_shoee_size(float s)
    {
        shoe_size=s;
    }
    string gat_name()
    {
        return name;
    }
    int get_age()
    {
        return age;
    }
    float getheight()
    {
        return height;
    }
    string get_gender()
    {
        return gender;
    }
    float get_shoe_size()
    {
        return shoe_size;
    }
    int get_id()
    {
        return id;
    }
};
class Shoe{
private:
float size;
float width;
string style;
string brand;
string demographic;
public:
	Shoe()
	{
		
	}
Shoe(float s ,float w,string style,string brand)
{
    size=s;
    width=w;
    this->style=style;
    this->brand=brand;
}
void set_size0(float l)
{
	size=l;
}
void set_width(float l)
{
	width=l;
}
void set_style(string s)
{
	style=s;
}
void set_brand(string b)
{
	brand=b;
}
void set_demographic(string d)
{
	this->demographic=d;
}
float get_size()
{
	return size;
}
float get_width()
{
	return width;
}
string get_style()
{
	return style;
}
string get_brand()
{
	return brand;
}
string get_demographic()
{
	return demographic;
}
void set_dem(User *U1)
{
    if((U1->get_age()>=0)&&(U1->get_age()<=2))
    this->demographic="toddler";
    else if((U1->get_age()>=6)&&(U1->get_age()<=9))
    {
         this->demographic="Process To Child";
    }
    else if((U1->get_age()>=10)&&(U1->get_age()<=12))
    {
         this->demographic="child";
    }
    else if((U1->get_age()>=13)&&(U1->get_age()<=19))
    {
         this->demographic="teenager";
    }
    else if(U1->get_age()>19)
    {
         this->demographic="Adult";
    }
    
    else {
	cout<<"Enter Wrong Age"<<endl; return;
	}

}
};
void print(User *u1,Shoe *s2)//global function
{
cout<<"Name :"<<u1->gat_name()<<endl;
cout<<"ID"<<u1->get_id()<<endl;
cout<<"Age"<<u1->get_age()<<endl;
cout<<"Height :"<<u1->getheight()<<endl;
cout<<"Gender "<<u1->get_gender()<<endl;
cout<<"Shoe Size: "<<u1->get_shoe_size()<<endl;
cout<<"Shoe Width: "<<s2->get_width()<<endl;
cout<<"Shoe Style :"<<s2->get_style()<<endl;
cout<<"Shoe Brand :"<<s2->get_brand()<<endl;
cout<<"Shoe Demographic :"<<s2->get_demographic()<<endl;
}
int main()
{
   	cout<<"Muhammad Haris 22k-4777"<<endl;
	cout<<"************************************************"<<endl;
    Shoe s1;
    User u1;
	string choice;
	string roleno;
	int id[2];
	string name;
	float height;
	string gender;
	float shoe_size;
	float size;
	float width;
	string style;
	string brand;
    int age;
    char cho;
	cout<<"Enter Your Name : "<<endl;
	cin>>name;
	cout<<"Enter Your Role_No :"<<endl;
	cin>>roleno;
	id[0]=std::stoi(roleno.substr(0,2));
    id[1]=std::stoi(roleno.substr(4));
	cout<<"Enter Your Height"<<endl;
	cin>>height;
	cout<<"Enter Your Gender"<<endl;
	cin>>gender;
    cout<<"Enter Your Age"<<endl;
    cin>>age;
	cout<<"Enter  Shoe_size :"<<endl;
	cin>>shoe_size;
	size=shoe_size;
	cout<<"Enter Width of Shoe"<<endl;
	cin>>width;
	cout<<"Enter Style of Your Shoe"<<endl;
	cin>>style;
	cout<<"Enter Brand Of Your Shoe"<<endl;
	cin>>brand;
u1=User(id[0],name,height,gender,shoe_size,age);
s1=Shoe(size,width,style,brand);
s1.set_dem(&u1);
cout<<"*****************************************"<<endl;
while(1){
	cout<<"*****************************************"<<endl;
cout<<"You Have Three Option IF You Want to see The Information Of Shoe and User Enter S\nElse If You Wanna to Update Record Of Shoe Enter P "<<endl;
cout<<"else you want to update the information of user Enter U"<<endl;
cout<<"Enter N For Ending Program"<<endl;
cin>>cho;
if((cho=='N')||(cho=='n'))
{
	cout<<"Good Byyyy"<<endl;
	return 0;
}
while(1){
if((cho=='S')||(cho=='s')||(cho=='p')||(cho=='P')||(cho=='U')||(cho=='u'))
{
    break;
}
cout<<"Enter Correctly"<<endl;
cin>>choice;
}
switch(cho){
case 'S':
	case 's':
print(&u1,&s1);
break;
case 'U':
	case 'u':
    do{
    cout<<"Which Thing You Want To Update You Can Update Your Name Age Gender Shoe Size  Or Height"<<endl;
    cout<<"For Update Enter Their Name Ig For Shoe Size Enter Shoe\nFor Name Enter Name\nFor Age Enter Age\n For Gender Enter Gender"<<endl;
    cin>>choice;
    if((choice=="Name")||(choice=="name"))
    {
        cout<<"Enter Name"<<endl;
        cin>>name;
        cout<<"Name Changed This ->"<<u1.gat_name();
        u1.set_name(name);
        cout<<": To This "<<u1.gat_name();
        }
         else if((choice=="Age")||(choice=="age"))
    {
        cout<<"Enter Age"<<endl;
        cin>>age;
        cout<<"Age Changed This -> "<<u1.get_age();
        u1.set_age(age);
        cout<<": To This  "<<u1.get_age();
        }
       else   if((choice=="Gender")||(choice=="gender"))
    {
        cout<<"Enter Gender"<<endl;
        cin>>gender;
        cout<<"Gender Changed This ->"<<u1.get_gender();
        u1.set_gender(gender);
        cout<<": To This "<<u1.get_gender();
        }
         else if((choice=="Shoe")||(choice=="shoe"))
    {
        cout<<"Enter New Size"<<endl;
        cin>>shoe_size;
        cout<<"Size Changed This ->"<<u1.get_shoe_size();
        u1.set_shoee_size(shoe_size);
        cout<<": To This "<<u1.get_shoe_size();
        }
           else if((choice=="Height")||(choice=="height"))
    {
        cout<<"Enter New Height"<<endl;
        cin>>height;
        cout<<"Height Changed This ->"<<u1.getheight();
        u1.set_height(height);
        cout<<": To This "<<u1.getheight();
        }
    cout<<"Do You Want to Update Again If Yes Enter Yes Else No"<<endl;
    cin>>choice;
    }while((choice=="Yes")||(choice=="yes"));
    break;
case 'P':
	case 'p':
    do{
    cout<<"Which Thing You Want To Update You Can Update Your Shoe Size, Width,Style,Brand Demographic will be set automatically"<<endl;
    cout<<"For Update Enter Their NameIg For  Size Enter Size (Case Sensitive)"<<endl;
    cin>>choice; 
    if((choice=="Size")||(choice=="size"))
    {
        cout<<"Enter Size"<<endl;
        cin>>size;
        cout<<"Size Changed This ->"<<s1.get_size();
        s1.set_size0(size);
        cout<<": To This "<<s1.get_size();
        }
     else  if((choice=="Width")||(choice=="width"))
    {
        cout<<"Enter Width"<<endl;
        cin>>width;
        cout<<"Width Changed This ->"<<s1.get_width();
        s1.set_width(width);
        cout<<": To This "<<s1.get_width();
        }
       else   if((choice=="Style")||(choice=="style"))
    {
        cout<<"Enter Style"<<endl;
        cin>>style;
        cout<<"Style Changed This -> "<<s1.get_style();
        s1.set_style(style);
        cout<<": To This "<<s1.get_style();
        }
         else if((choice=="Brand")||(choice=="brand"))
    {
        cout<<"Enter Brand"<<endl;
        cin>>brand;
        cout<<"Size Changed This ->"<<s1.get_brand();
        s1.set_brand(brand);
        cout<<": To This "<<s1.get_brand();
        }
    cout<<" Do You Want to Update Again If Yes Enter Yes Else No"<<endl;
    cin>>choice;
    }while((choice=="Yes")||(choice=="yes"));
    break;
}

}

}



