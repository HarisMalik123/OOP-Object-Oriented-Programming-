#include<iostream>
using namespace std;
#include<string>
#include<ctime>
class HeartRates{
private:
string name;
string id;
int day;
int year;
int month;
public:
HeartRates(string name, int d,int m,int y) {
	day=d;
	month=m;
	year=y;
this->name = name;
string roll_no="22k-4777";
this->id = roll_no.substr(4,7);
}
int calculate_age() {
int current_year = 2023;
int age = current_year - year;
return age;
}
int maximum_heart_rate()
{
return 220-calculate_age();
}
string target_heart_range()
{
int first;
int second;
first=maximum_heart_rate()*0.5;
second=maximum_heart_rate()*0.85;
return to_string(first)+"->"+to_string(second);
}
string get_info()
{
	string date_of_birth=to_string(day)+"/"+to_string(month)+"/"+to_string(year);
return name+"\n"+id+"\n"+date_of_birth+"\n"+"Age : "+to_string(calculate_age())+"\n"+"Maximum Heart Rate :"+to_string(maximum_heart_rate())+"\n"+"Target Heart Range "+ target_heart_range();
}
};
int main() {
		cout<<"Muhammad Haris 22k-4777"<<endl;
			cout<<"************************************************"<<endl;
string name;
int day,month,year;
cout << "Enter your name: " << endl;
cin >> name;
cout << "Enter your date of birth in this format DD/MM/YYYY: First Enter Date Then Enter Month Then Year for ig 2004 " << endl;
cin >> day>>month>>year;
// Validate input format
while (1) {

if((day>31)||(month>12)||(year<1111)||(year>=2023))
{
	cout<<"Enter Correctly"<<endl;
}
else 
break;

}

HeartRates h1(name,day,month,year);
//cout<<h1.calculate_age();
cout<<h1.get_info();

return 0;
}
