#include <iostream>
#include <string>

using namespace std;

// Forward declaration of Room class
class Room;

class Radiator {
private:
    static int num;
    string radiatorid;
    string ison;

public:
    Radiator() {
        if (num < 1) {
            string name = "22k-4777";
            name = name.substr(name.length() - 3, 3);
            num = std::stoi(name);
        }
        radiatorid = to_string(num);
        ison = "Off";
        num = num + 15;
    }

    string getRadiatorId() {
        return radiatorid;
    }

    void setRadiatorId(string id) {
        radiatorid = id;
    }

    void setIsOn() {
        ison = "On";
    }

    string get_status() {
        return this->ison;
    }

    void Heat(Room *ob);
};

int Radiator::num = 0;

class Room {
private:
    string roomName;
    int seating_capacity;
    int numRadiator;
    Radiator *R1;
    Radiator *R2;

public:
    Room() {
        seating_capacity = 12;
        numRadiator = 0;
        roomName = "None";
    }

    

    void is_heatedBY(Radiator& r1, Radiator& r2) {
        if (numRadiator >= 2) {
            cout << "Room at full capacity" << endl;
            return;
        }
        if ((&r1 == R1) || (&r1 == R2)) {
            cout << "Radiator " << r1.getRadiatorId() << " already added" << endl;
            return;
        }
        R1 = &r1;
        cout << "Radiator " << r1.getRadiatorId() << " added successfully" << endl;
        r1.setIsOn();
        ++numRadiator;

        if ((&r2 == R1) || (&r2 == R2)) {
            cout << "Radiator " << r2.getRadiatorId() << " already added" << endl;
            return;
        }
        R2 = &r2;
        cout << "Radiator " << r2.getRadiatorId() << " added successfully" << endl;
        r2.setIsOn();
        ++numRadiator;
    }

    void set_name(string name) {
        roomName = name;
    }

    void set_seating_capacity(int n) {
        seating_capacity = n;
    }

string get_roomname()
{
	return roomName;
}
int getseat()
{
	return seating_capacity;
}
};

void Radiator::Heat(Room *ob) {
    ob->set_name("Haris's Room");
    ob->set_seating_capacity(99);
}

int main() {
    cout << "Muhammad Haris 22k-4777" << endl;
    cout << "************************************************" << endl;
    Radiator r1;
    Radiator r2;
    Room R1;
    r1.Heat(&R1);
    cout<<"Room Name "<<R1.get_roomname()<<"Sitting capacity "<<R1.getseat()<<endl;
//R1.is_heatedBY(r1,r2);
R1.is_heatedBY(r1,r1);//both can be checked i am commenting it 
//R1.is_heatedBY(r1,r2);// same for this one i showed in outputs pics

cout<<"Radiator "<<r1.getRadiatorId()<<" is "<<r1.get_status()<<endl;
cout<<"Radiator "<<r2.getRadiatorId()<<" is "<<r2.get_status()<<endl;
return 0;
} 