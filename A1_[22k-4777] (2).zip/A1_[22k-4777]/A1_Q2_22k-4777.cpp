#include<iostream>
#include<vector>
using namespace std;
class Admin;
class DataScientist{
    private:
string firstname,lastname,highereduction,country;
int age,number_of_answer,number_of_question,Id;
public:
DataScientist()
{
    number_of_answer=0;
    number_of_answer=0;
}
DataScientist(string f,string l,string h,string c,int age,int id)
{
    firstname=f;
    lastname=l;
    highereduction=h;
country=c;
this->age=age;
Id=id;
}
void set_name(string name,int a)
{
	data[a].firstname=name;
}
void set_last(string name,int a)
{
	data[a].lastname=name;
}
void set_country(string name,int a)
{
	data[a].country=country;
}
string get_first(int a)
{
	return data[a].firstname;
}
string get_last(int a)
{
	return data[a].lastname;
}
string get_country(int a)
{
	return data[a].country;
}
void set_age(int ag,int a)
{
	data[a].age=ag;
}
int get_age(int a)
{
	return data[a].age;
}
static const int max=200;
static DataScientist data[max];
static int size;
int check(int id)
{
    for(int i=0;i<size;i++)
    {
        if(data[i].Id==id)
        {
        	cout<<"*********************************************************************"<<endl;
        	cout<<"Your Name "<<data[i].firstname<<endl<<"Last Name :"<<data[i].lastname<<endl<<"ID :"<<data[i].Id<<endl<<"Number Of Question Asked "<<data[i].number_of_question<<endl<<"Number Of Answer You Gave: "<<data[i].number_of_answer<<endl;
            return i;
        }
    }
    return -1;
}
void question(int id)
{
	string question;
	cout<<"Enter Your Question"<<endl;
	cin>>question;
	data[id].number_of_question++;
}
void answer(int id)
{string ans;
	cout<<"Which is Better Cyber Security Or Data Science (Obviously Cyber ) But You Your Answer"<<endl;
	cin>>ans;
	data[id].number_of_answer++;
}
static int append(string name,string l,string h,string c,int age,int id)
{
	int flag=0;
	
	if(size>=max)
	{
		cout<<"Out Of Capacity User"<<endl;
		return -1; 
	}
	else{
	for(int i=0;i<size;i++)
	{
		if(id==data[i].Id)
		{
			cout<<"ID Already Exist"<<endl;
				flag=1;
			return -3;
		
		}
	}
}
		if ((size < max)&&(flag!=1)) {
        data[size]=DataScientist(name,l,h,c,age,id);
        
        size++;
        cout<<"User Added Successfully"<<endl;
        return 0;
}
return 0;
}
};
class Admin
{
	private:
	int admin_id;
	string first_name,last_name,country;
	int age;
	static int total_user;
	string pass;
	public:
		Admin()
		{
		}
	Admin(string f,string l, string c,int age,string pass1)
	{
		this->admin_id=4777;
		this->first_name=f;
		this->last_name=l;
		this->age=age;
		this->country=c;
		this->pass=pass1;
	}
	void increase()	
	{
		total_user++;
	}
	int check(string pass2)
	{
		if(pass==pass2)
		{
			return 0;
		}
		else return -1;
	}
	void set_firstname(string name)
	{
		first_name=name;
	}
	void set_lastname(string name)
	{
		last_name=name;
	}
	void set_country1(string name)
	{
		country=name;
	}
	void set_age1(int ag)
	{
		age=ag;
	}
	string get_first()
	{
		return first_name;
	}
	string get_last()
	{
		return last_name;
	}
	string get_country()
	{
		return country;
	}
	int get_age()
	{
		return age;
	}
	int get_user()
	{
		return total_user;
	}
	int get_id()
	{
		return admin_id;
	}
};
DataScientist DataScientist::data[DataScientist::max];
int DataScientist::size=0;
int Admin::total_user=0;
int main(){
		cout<<"Muhammad Haris 22k-4777"<<endl;
			cout<<"************************************************"<<endl;
	Admin a1;
	string pass1;
    DataScientist s;
string f,l,h,c,rollno;

int age;
int id;
string choice;
char ch;

cout<<"Enter Your First Name"<<endl;
cin>>f;
cout<<"Enter Your Last Name"<<endl;
cin>>l;
cout<<"Enter Your Age"<<endl;
cin>>age;
cout<<"Create A Password"<<endl;
cin>>pass1;

cout<<"Enter Your Country"<<endl;
cin>>c;
rollno="22k-4777";
a1=Admin(f,l,c,age,pass1);
cout<<"Admin ID Created Succesfully"<<endl;
cout<<"**************************"<<endl;
while(1){
cout<<"If You are Admin Enter (Admin)"<<endl;
cout<<"**************"<<endl;
cout<<"If You are (User) Enter User"<<endl;
cout<<"**************"<<endl;
cout<<"If You Want to create Your Account As a User Enter (Create)"<<endl;
cout<<"**************"<<endl;
cout<<"If You Want to end the program enter Y/y"<<endl;
cin>>choice;
if((choice =="y")||(choice=="Y"))
{
	cout<<"By"<<endl;
    return 0;
}
while(1){
    if((choice=="admin")||(choice=="Admin")||(choice=="Create")||(choice=="create")||(choice=="User")||(choice=="user"))
    break;
    else{ cout<<"Wrong Choice Enter Correctly(Also Case Sensitive)"<<endl;
cin>>choice;
    }
}
if((choice=="User")||(choice=="user"))
{
cout<<"Enter Your Roll No Ex:22k-4777 "<<endl;
cin>>rollno;
id = std::stoi(rollno.substr(4, 7));
int a=s.check(id);
if(a<0)
{
    cout<<"Cannot Find Your Id Or May Be You Did Not Create Account"<<endl;
 
}
else{
cout<<"Do You Want Ask Question Or Answer Question if Yes Enter Question If You Want to Answer The Question Enter Answer"<<endl;
cin>>choice;
if(choice=="Answer"||choice=="answer")
{
    s.answer(a);
}
if(choice=="Question"||choice=="question")
{
	s.question(a);
}
cout<<"Do You Want To Update Your First Name Enter (First) If Last Name Enter (Last) if Country Enter Country(Country) Or Age Enter (Age)\n For Exit Enter No::"<<endl;
cin>>choice;
while(1)
{
	if((choice=="First")||(choice=="first")||(choice=="Last")||(choice=="last")||(choice=="country")||(choice=="Country")||(choice=="Age")||(choice=="age"))
	{
		break;
	}
	else if((choice=="No")||(choice=="no"))
	break;
	  else{ cout<<"Wrong Choice Enter Correctly(Also Case Sensitive)"<<endl;
cin>>choice;
    }
}
if((choice=="First")||(choice=="first"))
{
	cout<<"Enter First Name"<<endl;
	cin>>f;
	s.set_name(f,a);
	cout<<"Your Name Was Updated to :"<<s.get_first(a);
}
else if((choice=="last")||(choice=="Last"))
{
	cout<<"Enter last Name"<<endl;
	cin>>f;
	s.set_last(f,a);
	cout<<"Your Last Name Was Updated to :"<<s.get_last(a);
}
else if((choice=="Country")||(choice=="country"))
{cout<<"Enter Country Name"<<endl;
	cin>>f;
	s.set_country(f,a);
	cout<<"Your Country Was Updated to :"<<s.get_country(a);
}
else if((choice=="Age")||(choice=="age"))
{
	cout<<"Enter Age:"<<endl;
	cin>>age;
	s.set_age(age,a);
	cout<<"Your Age Was Updated "<<s.get_age(a)<<endl;
}
}
}
if((choice=="Create")||(choice=="create"))
{
cout<<"Enter Your First Name"<<endl;
cin>>f;
cout<<"Enter Your Last Name"<<endl;
cin>>l;
cout<<"Enter Your Higher Education"<<endl;
cin>>h;
cout<<"Enter Your Country"<<endl;
cin>>c;
cout<<"Enter Your Age "<<endl;
cin>>age ; 
cout<<"Enter Your Role No:"<<endl;
cin>>rollno;
id = std::stoi(rollno.substr(4,7));

if(DataScientist::append(f,l,h,c,age,id)>=0)
{
	DataScientist::append(f,l,h,c,age,id);
	cout<<"**********************************"<<endl;
a1.increase();

}
}
if((choice=="Admin")||(choice=="Admin"))
{
	cout<<"Enter Password"<<endl;
	cin>>pass1;
	if(a1.check(pass1)==0){
		cout<<"***************************************"<<endl;
		cout<<"First Name "<<a1.get_first()<<endl<<"Last Name "<<a1.get_last()<<endl<<"Age "<<a1.get_age()<<endl<<"Country "<<a1.get_country()<<endl<<"ID"<<a1.get_id()<<endl;
cout<<"Numbers Of Users Are "<<a1.get_user()<<endl;
	cout<<"**********************************************"<<endl;
	cout<<"Enter y if you want to Update Your Info"<<endl;
	cin>>choice;
	if((choice=="Y")||(choice=="y"))
	{
		cout<<"What Do You want to Update Your Information\nTo Update Name Enter(Name)\nTo Update Last Name Enter (Last)\nTo Update Enter Country Enter Country\nTo Update Age Enter (Age)"<<endl;
		cin>>choice;
		while(1){
		if((choice=="Name")||(choice=="name")||(choice=="last")||(choice=="Last")||(choice=="country")||(choice=="Country")||(choice=="Age")||(choice=="age"))
		{
			break;
		}
		else{
		cout<<"Enter Correct Also Case Sensitive"<<endl;
		cin>>choice;
	}
	}
	}
	cout<<"**********************************"<<endl;
	if((choice=="Name")||(choice=="name"))
	{
		cout<<"Enter New Name"<<endl;
		cin>>f;
		a1.set_firstname(f);
		cout<<"Name Was Changed to "<<f<<endl;
	}
	else if((choice=="Last")||(choice=="last"))
	{
		cout<<"Enter Last Name"<<endl;
		cin>>l;
		a1.set_lastname(l);
		cout<<"Name Was Changed to "<<l<<endl;
	}
	else if((choice=="Country")||(choice=="country"))
	{
		cout<<"Enter Country"<<endl;
		cin>>c;
		a1.set_country1(c);
		cout<<"Name Was Changed to "<<c<<endl;
	}
	else if((choice=="age")||(choice=="Age"))
	{
		cout<<"Enter Age"<<endl;
		cin>>age;
		a1.set_age1(age);
		cout<<"Age Was Changed to "<<age<<endl;
	}
}
}

}
}
